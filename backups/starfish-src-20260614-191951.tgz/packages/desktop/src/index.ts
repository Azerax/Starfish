// @starfish/desktop — the host shell (ring 3 base) that embeds the composed Governor.
export const VERSION = '0.8.0';
export { createHost, type Host, type HostOptions } from './host';
